When installing Anaconda, make sure that you comepletely remove the standalone PsychoPy distribution from your machine. Leaving it will cause library conflicts. You'll likely need another editor (I recommend PyCharm) and configure it to use the Anaconda Python install to run your scripts.

Before installing PsychoPy, ensure that the packages in the Install folder are on your system. Simply cd into the Install folder and run a pip install on each .whl file. Double click the AVBin file to install.
You will also need to install or upgrade PyOpenGL, pyserial, and wxpython.

The PsychoPy distribution does not work with versions of the PIL library > 2.9.0 due to a function renaming. To correct this error, type the following into your command prompt:

conda install pillow=2.9.0




To install PsychoPy for anaconda, type to following into your command prompt:

conda install -c cogsci psychopy=1.82.01

Test the PsychoPy install by running the function runPytest.py, located in C:\Programs\Anaconda2\Lib\site-packages\psychopy\tests. If this folder is not available, Anaconda may have installed for your user account only, in which case the file will be found in C:\Users\yourusername\AppData\Local\Continuum\Anaconda2\Lib\site-packages\psychopy\tests. This test will cycle through all of PsychoPy's functionality. My machine passes all but 19 tests, and skips 10 others. These are all related to running PsychoPy on a server, so can be safely (I think) ignored.

If these test pass, then you can run PsychoPy by simply importing the psychopy library into ou scripts. 



IMPORTANT NOTE:

To run psychopy stim windows independetly of other processes to prevent fps drops, you'll need to implement a function Theo wrote (see the file pscyho.py). This creates a subprocesses that connects via pipes to the psychopy window and stim files, and should maintain fps. Depending on the type of experiment you run (passive stim vs. animal trial initiation) you may experience some latency. I'm working on debugging that now. 